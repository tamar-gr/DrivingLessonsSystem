﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for TestMenu.xaml
    /// </summary>
    public partial class TestMenu : Window
    {
        BL.Ibl bl;
        string action;

        public TestMenu()
        {
            InitializeComponent();
            bl = BL.FactoryBL.GetBL();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            Window MenuWindow = new Menu();
            this.Close();
            MenuWindow.Show();
        }



        private void btnAddTest_Click(object sender, RoutedEventArgs e)
        {
            string content = "Add";
            BasicTest mytest = new BasicTest(content);
            this.Close();
            mytest.Show();
        }


        private void BtnUpdateTest_Click(object sender, RoutedEventArgs e)
        {
            txtTestCode.Visibility = System.Windows.Visibility.Visible;
            labelTestCode.Visibility = System.Windows.Visibility.Visible;
            btnOKTestCode.Visibility = System.Windows.Visibility.Visible;
            btnAddTest.Visibility = System.Windows.Visibility.Hidden;
            action = "update";
        }


        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            txtTestCode.Visibility = System.Windows.Visibility.Visible;
            labelTestCode.Visibility = System.Windows.Visibility.Visible;
            btnOKTestCode.Visibility = System.Windows.Visibility.Visible;
            action = "view";
        }

        private void btnShowAll_Click(object sender, RoutedEventArgs e)
        {
            DataGridTest myTest = new DataGridTest();
            this.Close();
            myTest.Show();
        }

        private void BtnOKTestCode_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Convert.ToInt32(txtTestCode.Text) < 10000000)
                    throw new Exception("Non-valid test code. Please enter a valid test code.");

                var found = bl.FindObjectById(Convert.ToInt32(txtTestCode.Text));

                if (action == "update")
                {
                    string content = "Update";
                    BasicTest myTest = new BasicTest(content, Convert.ToInt32(txtTestCode.Text));
                    this.Close();
                    myTest.Show();
                }
                else
                {
                    string content = "View";
                    BasicTester myTest = new BasicTester(content, Convert.ToInt32(txtTestCode.Text));
                    this.Close();
                    myTest.Show();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                txtTestCode.Text = "";
                txtTestCode.Visibility = System.Windows.Visibility.Hidden;
                labelTestCode.Visibility = System.Windows.Visibility.Hidden;
                btnOKTestCode.Visibility = System.Windows.Visibility.Hidden;
            }

        }

       
    }
}
