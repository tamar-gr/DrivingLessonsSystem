﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLWPF
{
    /// <summary>
    /// Interaction logic for Menu.xaml
    /// </summary>
    public partial class Menu : Window
    {
        public Menu()
        {
            InitializeComponent();
        } 

        private void BtnTesters_Click(object sender, RoutedEventArgs e)//go to testers menu
        {
            TesterMenu MytesterMenu = new TesterMenu();
            this.Close();
            MytesterMenu.Show();
        }

        private void BtnTrainees_Click(object sender, RoutedEventArgs e)
        {
            TraineeMenu MytraineeMenu = new TraineeMenu();
            this.Close();
            MytraineeMenu.Show();
        }

        private void BtnTests_Click(object sender, RoutedEventArgs e)
        {
            //player.Stop();
            TestMenu myTestMenu = new TestMenu();
            this.Close();
            myTestMenu.Show();
        }
    }
}


     
